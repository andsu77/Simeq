describe('Adição de Itens', () => {
    beforeEach(() => {
        cy.visit('http://localhost:3005/equipamentos')
    })
    
    it('Deve adicionar um novo equipamento', () => {
        cy.get('[data-cy="Adicionar-equipamento"]').click()
        cy.get('[data-cy="Nome-Equipamento"]').type('Novo Equipamento')
        cy.get('[data-cy="Descrição-Equipamento"]').type('Descriçãõ do novo equipamento')
        cy.get('[data-cy="Adicionar-Equipamento"]').click()
        cy.get('[data-cy="mensagem-sucesso"]').should('contain', 'Equipamento adicionado com sucesso')
    })
    it('Deve exibir mensagem de erro ao tentar adicionar um equipamento sem nome', () => {
        cy.get('[data-cy="Adicionar-equipamento"]').click()
        cy.get('[data-cy="Adicionar-Equipamento"]').click()
        cy.get('[data-cy="mensagem-erro"]').should('contain', 'Erro ao adicionar equipamento')
    })
})