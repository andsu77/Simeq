describe('Remoção de itens', () => {

    beforeEach((_) => {
        cy.visit('http://localhost:3005/equipamentos')
    })

    it('Deve exibir a lista de equipamentos', () => {
        cy.get('[data-cy="lista-equipamentos"]').should('exist')
        cy.get('[data-cy="lista-equipamentos"] tr').should('have.length.greaterThan', 0)
    });

    it('Deve remover um equipamento existente', () => {
        cy.get('[data-cy="remover-equipamento"]').first().click()
        cy.get('[data-cy="confirmar-remocao"]').click()
        cy.get('[data-cy="mensagem-sucesso"]').should('contain', 'Equipamento removido com sucesso')
    });

    it('Deve exibir mensagem de erro ao tentar excluir um dispositivo inexistente', () => {
        cy.get('[data-cy="remover-equipamento"]').first().click()
        cy.get('[data-cy="confirmar-remocao"]').click()
        cy.get('[data-cy="mensagem-erro"]').should('contain', 'Erro ao remover equipamento')
    });

});